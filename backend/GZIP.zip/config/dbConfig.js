module.exports = {
  connectionString: "mongodb+srv://dbAdmin:" + process.env.MONGO_ATLAS_PW + "@meancourse.n6pcukz.mongodb.net/?retryWrites=true&w=majority"
};